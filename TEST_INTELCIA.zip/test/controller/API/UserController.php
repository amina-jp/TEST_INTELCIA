<?php 
class UserController extends BaseController{
    private $userModel;

    public function __construct(UserModel $UserModel){
        $this->userModel=$UserModel;
    }

    public function checkUserExists() {
        if (!isset($_GET['email'])) {
            $this->sendError('Email parameter is required');
        }
      $email=$_GET['email'];
      $exists=$this->userModel->userExists($email);
      $this->sendResponse(['exists'=>$exists]);
    }
}
?>