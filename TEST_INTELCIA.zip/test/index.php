<?php
require_once 'conn_files.php';

// Initialiser les modèles et les contrôleurs
$Database = new Database($pdo); // Crée une instance de la classe Database
$UserModel = new UserModel($Database); // Crée une instance de la classe UserModel avec la base de données
$UserController = new UserController($UserModel); // Crée une instance de UserController avec le modèle UserModel

// Gérer la requête HTTP
if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['action']) && $_GET['action'] === 'checkUserExists') {
    // Appelle la méthode checkUserExists du UserController si la méthode est GET et l'action est 'checkUserExists'
    $UserController->checkUserExists();
} else {
    // Envoie une réponse d'erreur 404 si la requête ne correspond pas
    http_response_code(404);
    echo json_encode(['error' => 'Not Found']);
}
?>
