<?php
class UserModel {
    private $db;

    public function __construct(Database $db) {
        $this->db = $db;
    }

    public function UserExists($email) {
        $sql = "SELECT COUNT(*) as count FROM users WHERE email = :email";
        $stmt = $this->db-> query($sql, ['email' => $email]);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result['count'] > 0;
    }
}
?>
