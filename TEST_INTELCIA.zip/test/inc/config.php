<?php
return [
    'db' => [
        'host' => '',
        'dbname' => '',
        'user' => '',
        'password' =>'',
    ],
];
?>