<?php
class Database {
    private $pdo;

    public function __construct($host, $port, $dbname, $user, $password) {
        $dsn = "pgsql:host=$host;port=$port;dbname=$dbname";
        try {
            $this->pdo = new PDO($dsn, $user, $password);
            $this->pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch (PDOException $e) {
            echo 'Connection failed: ' . $e->getMessage();
        }
    }

    public function prepare($query) {
        return $this->pdo->prepare($query);
    }
}
?>
