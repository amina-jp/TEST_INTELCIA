<?php
class LogModel {
    private $db;

    public function __construct($db) {
        $this->db = $db;
    }

    public function log($actionType, $tableName, $dataBefore, $dataAfter, $executionStart, $executionEnd, $executionDuration, $responseJson, $executedBy) {
        try {
            $query = "INSERT INTO api_logs (action_type, table_name, data_before, data_after, execution_start, execution_end, execution_duration, response_json, executed_by) 
                      VALUES (:action_type, :table_name, :data_before, :data_after, :execution_start, :execution_end, :execution_duration, :response_json, :executed_by)";
            $stmt = $this->db->prepare($query);
            $stmt->execute([
                'action_type' => $actionType,
                'table_name' => $tableName,
                'data_before' => $dataBefore,
                'data_after' => $dataAfter,
                'execution_start' => $executionStart,
                'execution_end' => $executionEnd,
                'execution_duration' => $executionDuration,
                'response_json' => $responseJson,
                'executed_by' => $executedBy
            ]);
        } catch (PDOException $e) {
            error_log('Database error: ' . $e->getMessage());
        }
    }
}
?>
