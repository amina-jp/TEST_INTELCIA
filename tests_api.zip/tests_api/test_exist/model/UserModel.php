<?php
class UserModel {
    private $db;
    private $logModel;
    private $config;

    public function __construct(Database $db, LogModel $logModel) {
        $this->db = $db;
        $this->logModel = $logModel;
        $this->config = require 'inc/config.php'; // Inclure le fichier de configuration
    }

    // Vérifie si un utilisateur avec l'email donné existe et retourne les détails de l'utilisateur
    public function getUserByLogin($login) {
        $startTime = microtime(true); // Début du chronométrage
        $executionStart = date('Y-m-d H:i:s'); // Début de l'exécution

        try {
            $query = "SELECT login, fname, lname, email FROM jetauth.users WHERE login = :login";
            $stmt = $this->db->prepare($query);
            $stmt->execute(['login' => $login]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);

            $executionEnd = date('Y-m-d H:i:s'); // Fin de l'exécution
            $executionTime = microtime(true) - $startTime; // Durée d'exécution

            // Journaliser les détails
            $this->logModel->log(
                'check_exists',
                'jetauth.users',
                json_encode(['login' => $login]), // data_before
                json_encode(['exists' => $user !== false]), // data_after
                $executionStart,
                $executionEnd,
                $executionTime . ' seconds',
                json_encode(['success' => $user !== false]),
                $this->getExecutedBy()
            );

            return $user;
        } catch (PDOException $e) {
            $executionEnd = date('Y-m-d H:i:s'); // Fin de l'exécution
            $executionTime = microtime(true) - $startTime; // Durée d'exécution
            error_log('Database error: ' . $e->getMessage());

            // Journaliser l'erreur
            $this->logModel->log(
                'check_exists',
                'jetauth.users',
                json_encode(['login' => $login]), // data_before
                json_encode(['success' => false, 'message' => $e->getMessage()]), // data_after
                $executionStart,
                $executionEnd,
                $executionTime . ' seconds',
                json_encode(['success' => false]),
                $this->getExecutedBy()
            );

            return false;
        }
    }

    private function getExecutedBy() {
        return $this->config['user'] ? $this->config['user'] : 'unknown';
    }
}
?>
