<?php
class UserController extends BaseController {
    private $userModel;

    public function __construct(UserModel $userModel) {
        $this->userModel = $userModel;
    }

    public function checkUserExists() {
        if (!isset($_GET['login']) || empty($_GET['login'])) {
            $this->sendError('Login parameter is required');
            return;
        }

        $login = $_GET['login'];
        $user = $this->userModel->getUserByLogin($login);

        if ($user) {
            $response = [
                'exists' => true,
                'login' => $user['login'],
                'fname' => $user['fname'],
                'lname' => $user['lname'],
                'email' => $user['email']
            ];
        } else {
            $response = ['exists' => false];
        }

        $this->sendResponse($response);
    }

    public function getUserInfo() {
        if (!isset($_GET['login']) || empty($_GET['login'])) {
            $this->sendError('Login parameter is required');
            return;
        }

        $login = $_GET['login'];
        $user = $this->userModel->getUserByLogin($login);

        if ($user) {
            $response = [
                'login' => $user['login'],
                'fname' => $user['fname'],
                'lname' => $user['lname'],
                'email' => $user['email']
            ];
        } else {
            $response = ['error' => 'User not found'];
        }

        $this->sendResponse($response);
    }
}
?>
