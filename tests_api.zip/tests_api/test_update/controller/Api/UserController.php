<?php
class UserController extends BaseController {
    private $userModel;

    public function __construct(UserModel $userModel) {
        $this->userModel = $userModel;
    }

    public function updateUser() {
        try {
            $data = $this->getRequestData();
            $executedBy = $_SERVER['REMOTE_USER'] ?? 'unknown';

            if (!isset($data['login'])) {
                throw new InvalidArgumentException('Login parameter is required');
            }

            $login = $data['login'];
            unset($data['login']);

            $updatedUser = $this->userModel->updateUser($login, $data);

            if ($updatedUser) {
                $this->sendResponse(['success' => true, 'message' => 'User information updated successfully', 'user' => $updatedUser]);
            } else {
                $this->sendError('Failed to update user information');
            }
        } catch (InvalidArgumentException $e) {
            $this->sendError($e->getMessage(), 400);
        } catch (PDOException $e) {
            $this->sendError('Database error: ' . $e->getMessage(), 500);
        } catch (Exception $e) {
            $this->sendError('An unexpected error occurred: ' . $e->getMessage(), 500);
        }
    }
}
?>
