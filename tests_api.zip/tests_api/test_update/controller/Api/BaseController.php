<?php
class BaseController {
    protected function sendResponse($data) {
        header('Content-Type: application/json');
        echo json_encode($data);
        exit;
    }

    protected function sendError($message, $code = 400) {
        http_response_code($code);
        $this->sendResponse(['error' => $message]);
    }

    protected function getRequestData() {
        return json_decode(file_get_contents('php://input'), true);
    }
}
?>
