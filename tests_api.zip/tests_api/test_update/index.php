<?php
require_once 'inc/conn_files.php';
require_once 'Model/Database.php';
require_once 'Model/UserModel.php';
require_once 'Model/LogModel.php';
require_once 'Controller/Api/BaseController.php';
require_once 'Controller/Api/UserController.php';

// Initialiser les modèles et les contrôleurs
$database = new Database($pdo);
$logModel = new LogModel($database);
$userModel = new UserModel($database, $logModel);
$userController = new UserController($userModel);

// Gérer la requête HTTP
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'updateUser') {
    $userController->updateUser();
} else {
    http_response_code(404);
    echo json_encode(['error' => 'Not Found']);
}
?>
