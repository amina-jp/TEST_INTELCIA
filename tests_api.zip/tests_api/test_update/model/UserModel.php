<?php
class UserModel {
    private $db;
    private $logModel;
    private $executedBy;

    public function __construct(Database $database, LogModel $logModel) {
        $this->db = $database;
        $this->logModel = $logModel;
        
        // Récupérer l'utilisateur exécutant depuis config.php
        $config = include '../inc/config.php';
        $this->executedBy = $config['user'] ?? 'unknown';
    }

    public function userExists($login) {
        try {
            $query = "SELECT COUNT(*) FROM jetauth.users WHERE login = :login";
            $stmt = $this->db->prepare($query);
            $this->db->execute($stmt, ['login' => $login]);
            return $stmt->fetchColumn() > 0;
        } catch (PDOException $e) {
            error_log('Database error: ' . $e->getMessage());
            return false;
        }
    }

    public function updateUser($currentLogin, $data) {
        try {
            $startTime = microtime(true);

            if (empty($currentLogin) || !$this->userExists($currentLogin)) {
                // Log l'erreur si l'utilisateur n'existe pas
                $responseJson = json_encode(['success' => false, 'message' => 'User does not exist']);
                $this->logModel->log(
                    null, // user_identifier
                    'update',
                    null, // old_data
                    null, // new_data
                    $responseJson,
                    microtime(true) - $startTime, // execution_duration
                    $this->executedBy
                );
                throw new Exception('User does not exist');
            }

            // Validation des données pour éviter la modification des champs inchangeables
            foreach ($data as $key => $value) {
                if (in_array($key, ['login', 'fname', 'lname'])) {
                    throw new Exception("The field $key cannot be modified.");
                }
            }

            // Récupérer les anciennes données pour les logs
            $query = "SELECT * FROM jetauth.users WHERE login = :login";
            $stmt = $this->db->prepare($query);
            $this->db->execute($stmt, ['login' => $currentLogin]);
            $oldData = $stmt->fetch(PDO::FETCH_ASSOC);

            // Construction dynamique de la requête d'update
            $fields = [];
            $params = [];
            foreach ($data as $key => $value) {
                if (!in_array($key, ['login', 'fname', 'lname'])) {
                    $fields[] = "$key = :$key";
                    $params[$key] = $value;
                }
            }
            $params['currentLogin'] = $currentLogin;

            if (empty($fields)) {
                throw new Exception('No valid fields to update.');
            }

            $query = "UPDATE jetauth.users SET " . implode(', ', $fields) . " WHERE login = :currentLogin";
            $stmt = $this->db->prepare($query);
            $this->db->execute($stmt, $params);
            $executionTime = microtime(true) - $startTime;

            // Récupérer les nouvelles données pour les logs
            $query = "SELECT * FROM jetauth.users WHERE login = :login";
            $stmt = $this->db->prepare($query);
            $this->db->execute($stmt, ['login' => $currentLogin]);
            $newData = $stmt->fetch(PDO::FETCH_ASSOC);

            // Insérer les logs via LogModel
            $this->logModel->log(
                $oldData['users_id'],
                'update',
                json_encode($oldData),
                json_encode($newData),
                json_encode(['success' => true]),
                $executionTime . ' seconds',
                $this->executedBy
            );

            return $newData; // Renvoie les données mises à jour
        } catch (PDOException $e) {
            error_log('Database error: ' . $e->getMessage());
            return false;
        } catch (Exception $e) {
            error_log('Validation error: ' . $e->getMessage());
            return false;
        }
    }
}
?>
