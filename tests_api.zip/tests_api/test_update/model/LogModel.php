<?php
class LogModel {
    private $db;

    public function __construct(Database $db) {
        $this->db = $db;
    }

    public function log($userIdentifier, $actionType, $oldData, $newData, $responseJson, $executionDuration, $executedBy) {
        try {
            $query = "INSERT INTO api_logs (user_identifier, action_type, old_data, new_data, response_json, execution_duration, executed_by) 
                      VALUES (:user_identifier, :action_type, :old_data, :new_data, :response_json, :execution_duration, :executed_by)";
            $stmt = $this->db->prepare($query);
            $stmt->execute([
                'user_identifier' => $userIdentifier,
                'action_type' => $actionType,
                'old_data' => $oldData,
                'new_data' => $newData,
                'response_json' => $responseJson,
                'execution_duration' => $executionDuration,
                'executed_by' => $executedBy
            ]);
        } catch (PDOException $e) {
            error_log('Database error: ' . $e->getMessage());
        }
    }
}
?>
