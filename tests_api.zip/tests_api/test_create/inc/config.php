<?php
return [
    'host' => '',
    'port' => '5432',
    'dbname' => '',
    'user' => '',
    'password' => 'passwd_db'
];
?>
