<?php
// Charger les configurations
$config = include 'config.php';

// Configurer la connexion à la base de données
try {
    $dsn = 'pgsql:host=' . $config['host'] . ';port=' . $config['port'] . ';dbname=' . $config['dbname'];
    $pdo = new PDO($dsn, $config['user'], $config['password']);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die('Erreur de connexion à la base de données: ' . $e->getMessage());
}

// Autoloading des classes
spl_autoload_register(function ($class) {
    $prefix = ''; // Ajustez ce préfixe si nécessaire
    $base_dir = __DIR__ . '/../'; // Assurez-vous que ce chemin est correct
    $len = strlen($prefix);
    if (strncmp($prefix, $class, $len) !== 0) {
        return;
    }
    $relative_class = substr($class, $len);
    $file = $base_dir . str_replace('\\', '/', $relative_class) . '.php';
    if (file_exists($file)) {
        require $file;
    }
});
?>
