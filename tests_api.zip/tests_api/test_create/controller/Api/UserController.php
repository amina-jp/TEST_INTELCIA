<?php
class UserController extends BaseController {
    private $userModel;

    public function __construct(UserModel $userModel) {
        $this->userModel = $userModel;
    }

    public function createUser() {
        try {
            $data = json_decode(file_get_contents('php://input'), true);
            $executedBy = $_SERVER['REMOTE_USER'] ?? 'unknown';

            // Validation des champs requis
            if (!isset($data['login']) || !isset($data['fname']) || !isset($data['lname']) || !isset($data['email']) || !isset($data['phone']) || !isset($data['place']) || !isset($data['division']) || !isset($data['manager']) || !isset($data['description'])) {
                $this->sendError('Login, first name, last name, email, phone, place, division, manager, and description are required.');
                return;
            }

            $login = $data['login'];
            $fname = $data['fname'];
            $lname = $data['lname'];
            $email = $data['email'];
            $phone = $data['phone'];
            $place = $data['place'];
            $division = $data['division'];
            $manager = $data['manager'];
            $description = $data['description'];

            $this->userModel->createUser($login, $fname, $lname, $email, $phone, $place, $division, $manager, $description, $executedBy);

            $user = $this->userModel->getUserByLogin($login);
            $this->sendResponse(['message' => 'User created successfully', 'user' => $user]);
        } catch (InvalidArgumentException $e) {
            $this->sendError($e->getMessage(), 400);
        } catch (PDOException $e) {
            $this->sendError('Database error: ' . $e->getMessage(), 500);
        } catch (Exception $e) {
            $this->sendError('An unexpected error occurred: ' . $e->getMessage(), 500);
        }
    }
}
?>
