<?php
class UserModel {
    private $db;
    private $logModel;

    public function __construct(Database $db, LogModel $logModel) {
        $this->db = $db;
        $this->logModel = $logModel;
    }

    public function createUser($login, $fname, $lname, $email, $phone, $place, $division, $manager, $description, $executedBy) {
        $startTime = microtime(true);

        try {
            // Vérifier si l'utilisateur existe déjà
            if ($this->userExists($login)) {
                throw new Exception('User already exists.');
            }

            $sql = "INSERT INTO jetauth.users (login, fname, lname, email, phone, place, division, manager, description) 
                    VALUES (:login, :fname, :lname, :email, :phone, :place, :division, :manager, :description)";
            $this->db->query($sql, [
                'login' => $login,
                'fname' => $fname,
                'lname' => $lname,
                'email' => $email,
                'phone' => $phone,
                'place' => $place,
                'division' => $division,
                'manager' => $manager,
                'description' => $description
            ]);

            // Vérifier si l'utilisateur a bien été créé
            $user = $this->getUserByLogin($login);
            if (!$user) {
                throw new Exception('User creation failed.');
            }

            $executionDuration = microtime(true) - $startTime;
            $this->logModel->log(
                null,  // Pas de user_identifier avant la création
                'INSERT',
                json_encode(['login' => $login, 'fname' => $fname, 'lname' => $lname, 'email' => $email, 'phone' => $phone, 'place' => $place, 'division' => $division, 'manager' => $manager, 'description' => $description]),
                json_encode($user),
                $executionDuration,
                $executedBy
            );

        } catch (Exception $e) {
            error_log('Error: ' . $e->getMessage());

            $executionDuration = microtime(true) - $startTime;
            $this->logModel->log(
                null,  // Pas de user_identifier avant la création
                'INSERT',
                json_encode(['login' => $login, 'fname' => $fname, 'lname' => $lname, 'email' => $email, 'phone' => $phone, 'place' => $place, 'division' => $division, 'manager' => $manager, 'description' => $description]),
                json_encode(['success' => false, 'message' => $e->getMessage()]),
                $executionDuration,
                $executedBy
            );

            throw $e; // Re-throw the exception to be handled by the controller
        }
    }

    public function getUserByLogin($login) {
        $sql = "SELECT login, fname, lname, email, date_creation FROM jetauth.users WHERE login = :login";
        $stmt = $this->db->query($sql, ['login' => $login]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function userExists($login) {
        $sql = "SELECT COUNT(*) as count FROM jetauth.users WHERE login = :login";
        $stmt = $this->db->query($sql, ['login' => $login]);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result['count'] > 0;
    }
}
?>
