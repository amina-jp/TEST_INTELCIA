<?php
class LogModel {
    private $db;
    private $executedBy;

    public function __construct($db) {
        $this->db = $db;

        // Charger la configuration
        $config = include __DIR__ . '/../inc/config.php';
        $this->executedBy = $config['user']; // Utilisateur configuré pour la base de données
    }

    public function log($userIdentifier, $actionType, $actionDetails, $responseJson, $executionDuration) {
        try {
            $query = "INSERT INTO api_logs (action_type, table_name, data_before, data_after, execution_start, execution_end, execution_duration, response_json, executed_by) 
                      VALUES (:action_type, :table_name, :data_before, :data_after, :execution_start, :execution_end, :execution_duration, :response_json, :executed_by)";
            $stmt = $this->db->prepare($query);
            $stmt->execute([
                'action_type' => $actionType,
                'table_name' => 'jetauth.users', // Nom de la table concernée
                'data_before' => null,  // Adapté en fonction de l'action
                'data_after' => $actionDetails,
                'execution_start' => date('Y-m-d H:i:s', time()), // Date/heure actuelle pour début
                'execution_end' => date('Y-m-d H:i:s', time() + $executionDuration), // Date/heure actuelle + durée pour fin
                'execution_duration' => $executionDuration,
                'response_json' => $responseJson,
                'executed_by' => $this->executedBy
            ]);
        } catch (PDOException $e) {
            error_log('Database error: ' . $e->getMessage());
        }
    }
}
?>
