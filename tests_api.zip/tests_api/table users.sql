-- Table: jetauth.users

-- DROP TABLE IF EXISTS jetauth.users;

CREATE TABLE IF NOT EXISTS jetauth.users
(
    users_id numeric NOT NULL,
    lname character varying(30) COLLATE pg_catalog."default",
    fname character varying(30) COLLATE pg_catalog."default",
    email character varying(70) COLLATE pg_catalog."default",
    phone character varying(20) COLLATE pg_catalog."default",
    place character varying(70) COLLATE pg_catalog."default",
    division character varying(70) COLLATE pg_catalog."default",
    manager character varying(70) COLLATE pg_catalog."default",
    login character varying(20) COLLATE pg_catalog."default" NOT NULL,
    passwd character varying(50) COLLATE pg_catalog."default" NOT NULL,
    active smallint NOT NULL DEFAULT 0,
    default_app_id numeric,
    last_connexion timestamp without time zone,
    description character varying(255) COLLATE pg_catalog."default",
    date_creation timestamp without time zone DEFAULT statement_timestamp(),
    date_modification timestamp without time zone DEFAULT statement_timestamp(),
    t_user_id numeric NOT NULL,
    CONSTRAINT users_pkey PRIMARY KEY (users_id),
    CONSTRAINT users_login_key UNIQUE (login),
    CONSTRAINT fk_t_user_users FOREIGN KEY (t_user_id)
        REFERENCES jetauth.t_user (t_user_id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION,
    CONSTRAINT ck_users_active CHECK (active = ANY (ARRAY[0, 1]))
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS jetauth.users
    OWNER to jetauth;
-- Index: idx_users_fname__lname

-- DROP INDEX IF EXISTS jetauth.idx_users_fname__lname;

CREATE INDEX IF NOT EXISTS idx_users_fname__lname
    ON jetauth.users USING btree
    (fname COLLATE pg_catalog."default" ASC NULLS LAST, lname COLLATE pg_catalog."default" ASC NULLS LAST)
    TABLESPACE pg_default;

-- Trigger: t_arc_users_ad

-- DROP TRIGGER IF EXISTS t_arc_users_ad ON jetauth.users;

CREATE OR REPLACE TRIGGER t_arc_users_ad
    AFTER DELETE
    ON jetauth.users
    FOR EACH ROW
    EXECUTE FUNCTION jetauth.trigger_fct_t_arc_users_ad();

ALTER TABLE jetauth.users
    DISABLE TRIGGER t_arc_users_ad;

-- Trigger: t_arc_users_ai

-- DROP TRIGGER IF EXISTS t_arc_users_ai ON jetauth.users;

CREATE OR REPLACE TRIGGER t_arc_users_ai
    AFTER INSERT
    ON jetauth.users
    FOR EACH ROW
    EXECUTE FUNCTION jetauth.trigger_fct_t_arc_users_ai();

ALTER TABLE jetauth.users
    DISABLE TRIGGER t_arc_users_ai;

-- Trigger: t_arc_users_au

-- DROP TRIGGER IF EXISTS t_arc_users_au ON jetauth.users;

CREATE OR REPLACE TRIGGER t_arc_users_au
    AFTER UPDATE 
    ON jetauth.users
    FOR EACH ROW
    EXECUTE FUNCTION jetauth.trigger_fct_t_arc_users_au();

ALTER TABLE jetauth.users
    DISABLE TRIGGER t_arc_users_au;

-- Trigger: t_users_bi

-- DROP TRIGGER IF EXISTS t_users_bi ON jetauth.users;

CREATE OR REPLACE TRIGGER t_users_bi
    BEFORE INSERT
    ON jetauth.users
    FOR EACH ROW
    EXECUTE FUNCTION jetauth.trigger_fct_t_users_bi();

-- Trigger: t_users_bu

-- DROP TRIGGER IF EXISTS t_users_bu ON jetauth.users;

CREATE OR REPLACE TRIGGER t_users_bu
    BEFORE UPDATE 
    ON jetauth.users
    FOR EACH ROW
    EXECUTE FUNCTION jetauth.trigger_fct_t_users_bu();