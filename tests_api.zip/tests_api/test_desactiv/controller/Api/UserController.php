<?php
class UserController extends BaseController {
    private $userModel;


    public function __construct(UserModel $userModel) {
        $this->userModel = $userModel;
       
    }

    public function deleteUser() {
        try {
            $data = $this->getRequestData();

            if (!isset($data['login'])) {
                throw new InvalidArgumentException('Login parameter is required');
            }

            $login = $data['login'];

            $success = $this->userModel->deleteUser($login);

            if ($success) {
                $this->sendResponse(['success' => true, 'message' => 'User deleted successfully']);
            } else {
                $this->sendError('Failed to delete user');
            }
        } catch (InvalidArgumentException $e) {
            $this->sendError($e->getMessage(), 400);
        } catch (PDOException $e) {
            $this->sendError('Database error: ' . $e->getMessage(), 500);
        } catch (Exception $e) {
            $this->sendError('An unexpected error occurred: ' . $e->getMessage(), 500);
        }
    }
}
?>
