<?php
class UserModel {
    private $db;
    private $logModel;
    private $config;

    public function __construct(Database $db, LogModel $logModel, $config) {
        $this->db = $db;
        $this->logModel = $logModel;
        $this->config = $config;
    }

    public function deleteUser($login) {
        $startTime = microtime(true);
        $executedBy = $this->config['user'];

        // Vérifie si l'utilisateur existe
        if (!$this->userExists($login)) {
            $executionDuration = microtime(true) - $startTime;
            $this->logModel->log(
                null,
                'DELETE',
                'User does not exist',
                json_encode(['success' => false, 'message' => 'User does not exist']),
                $executionDuration,
                $executedBy
            );
            return false;
        }

        // Vérifie si tous les champs requis sont présents
        if (!$this->checkRequiredFields($login)) {
            $executionDuration = microtime(true) - $startTime;
            $this->logModel->log(
                null,
                'DELETE',
                'Required fields missing',
                json_encode(['success' => false, 'message' => 'Required fields missing']),
                $executionDuration,
                $executedBy
            );
            return false;
        }

        // Récupère les détails de l'utilisateur avant la suppression pour la journalisation
        $userDetails = $this->getUserByLogin($login);

        try {
            $sql = "DELETE FROM jetauth.users WHERE login = :login";
            $stmt = $this->db->prepare($sql);
            $stmt->execute(['login' => $login]);

            $executionDuration = microtime(true) - $startTime;
            $success = $stmt->rowCount() > 0;

            // Journalise l'action
            $this->logModel->log(
                $login,
                'DELETE',
                json_encode($userDetails),
                json_encode(['success' => $success]),
                $executionDuration,
                $executedBy
            );

            return $success;
        } catch (PDOException $e) {
            error_log('Database error: ' . $e->getMessage());

            $executionDuration = microtime(true) - $startTime;
            $this->logModel->log(
                $login,
                'DELETE',
                json_encode($userDetails),
                json_encode(['success' => false, 'message' => $e->getMessage()]),
                $executionDuration,
                $executedBy
            );

            return false;
        }
    }

    public function userExists($login) {
        $sql = "SELECT COUNT(*) FROM jetauth.users WHERE login = :login";
        $stmt = $this->db->prepare($sql);
        $stmt->execute(['login' => $login]);
        return $stmt->fetchColumn() > 0;
    }

    private function getUserByLogin($login) {
        $sql = "SELECT * FROM jetauth.users WHERE login = :login";
        $stmt = $this->db->prepare($sql);
        $stmt->execute(['login' => $login]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    private function checkRequiredFields($login) {
        $sql = "SELECT login, fname, lname FROM jetauth.users WHERE login = :login";
        $stmt = $this->db->prepare($sql);
        $stmt->execute(['login' => $login]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        // Vérifie si tous les champs requis sont présents
        return !empty($user['login']) && !empty($user['fname']) && !empty($user['lname']);
    }
}
?>
