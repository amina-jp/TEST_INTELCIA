<?php
class LogModel {
    private $db;

    public function __construct($db) {
        $this->db = $db;
    }

    public function log($userIdentifier, $actionType, $actionDetails, $responseJson, $executionDuration, $executedBy) {
        try {
            $query = "INSERT INTO api_logs (user_identifier, action_type, action_details, response_json, execution_duration, executed_by) 
                      VALUES (:user_identifier, :action_type, :action_details, :response_json, :execution_duration, :executed_by)";
            $stmt = $this->db->prepare($query);
            $stmt->execute([
                'user_identifier' => $userIdentifier,
                'action_type' => $actionType,
                'action_details' => $actionDetails,
                'response_json' => $responseJson,
                'execution_duration' => $executionDuration,
                'executed_by' => $executedBy
            ]);
        } catch (PDOException $e) {
            error_log('Database error: ' . $e->getMessage());
        }
    }
}
?>
