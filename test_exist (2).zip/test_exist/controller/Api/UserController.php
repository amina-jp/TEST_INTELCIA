<?php
class UserController extends BaseController {
    private $userModel;

    public function __construct(UserModel $userModel) {
        $this->userModel = $userModel;
    }

    public function checkUserExists() {
        if (!isset($_GET['email']) || empty($_GET['email'])) {
            $this->sendError('Le paramètre email est requis');
            return;
        }

        $email = $_GET['email'];
        $user = $this->userModel->getUserByEmail($email);

        if ($user) {
            $response = [
                'exists' => true,
                'login' => $user['login'],
                'fname' => $user['fname'],
                'lname' => $user['lname'],
                'email' => $user['email']
            ];
        } else {
            $response = ['exists' => false];
        }

        $this->sendResponse($response);
    }

    public function getUserInfo() {
        if (!isset($_GET['email']) || empty($_GET['email'])) {
            $this->sendError('Le paramètre email est requis');
            return;
        }

        $email = $_GET['email'];
        $user = $this->userModel->getUserByEmail($email);

        if ($user) {
            $response = [
                'login' => $user['login'],
                'fname' => $user['fname'],
                'lname' => $user['lname'],
                'email' => $user['email']
            ];
        } else {
            $response = ['error' => 'Utilisateur non trouvé'];
        }

        $this->sendResponse($response);
    }
}
?>
