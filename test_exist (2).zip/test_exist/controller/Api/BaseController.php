<?php
class BaseController {
    protected function sendResponse($data, $status = 200) {
        http_response_code($status);
        header('Content-Type: application/json');
        echo json_encode($data);
        exit;
    }

    protected function sendError($message, $status = 400) {
        $this->sendResponse(['error' => $message], $status);
    }
}
?>
