<?php
require_once 'inc/conn_files.php';
require_once 'Model/Database.php';
require_once 'Model/UserModel.php';
require_once 'Model/LogModel.php';
require_once 'Controller/Api/BaseController.php';
require_once 'Controller/Api/UserController.php';

// Initialiser les modèles et les contrôleurs
$database = new Database($pdo);
$logModel = new LogModel($database);
$userModel = new UserModel($database, $logModel);
$userController = new UserController($userModel, $logModel);

// Gérer la requête
if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['action'])) {
    $action = $_GET['action'];
    if ($action === 'checkUserExists') {
        $userController->checkUserExists();
    } elseif ($action === 'getUserInfo') {
        $userController->getUserInfo();
    } else {
        http_response_code(404);
        echo json_encode(['error' => 'Not Found']);
    }
} else {
    http_response_code(404);
    echo json_encode(['error' => 'Not Found']);
}
?>
